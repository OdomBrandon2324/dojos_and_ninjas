package com.brandonodom.dojoandninjas.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.brandonodom.dojoandninjas.models.Ninja;
import com.brandonodom.dojoandninjas.repositories.NinjaRepository;




@Service
public class NinjaService {
	@Autowired
	private NinjaRepository ninjaRepository;

	
	// ----- CREATE -----
	public Ninja createNinja(Ninja newNinja) {
		return ninjaRepository.save(newNinja);
}

}